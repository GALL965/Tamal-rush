package com.tamalrush.api.controller;

import com.tamalrush.api.dto.RunPayload;
import com.tamalrush.api.service.StatsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class GameController {

    private final StatsService statsService;

    @PostMapping("/run")
    public ResponseEntity<?> saveRun(@RequestBody RunPayload payload) {
        statsService.saveRun(payload);
        return ResponseEntity.ok("Run guardada");
    }
}
